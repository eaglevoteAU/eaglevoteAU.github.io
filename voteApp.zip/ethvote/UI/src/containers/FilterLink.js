import React from 'react';
import { Link } from 'react-router';

const FilterLink = ({ filter, children }) => (
  <Link
    to={filter === 'LivePolls' ? '' : filter}
    activeStyle={{
      textDecoration: 'none',
      color: 'blue'
    }}
  >
    {children }
  </Link>
);

export default FilterLink
