import { connect } from 'react-redux';
import PollList from '../components/PollList'
import voted from '../actions'

const getVisiblePolls = (polls, filter) => {
  switch (filter) {
    case 'LivePolls':
      return polls
    case 'VotedPolls':
      return polls.filter(p => p.voted)
  }
}

const mapStateToProps = (state, ownProps) => {
  return {
    polls: getVisiblePolls(state.polls, ownProps.filter)
  }
}

const VisiblePollList = connect(
  mapStateToProps
)(PollList)

export default VisiblePollList
