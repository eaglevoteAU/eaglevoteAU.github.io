import { combineReducers } from 'redux'
import polls from './polls'
import visibilityFilter from './visibilityFilter'

const votingApp = combineReducers({
  polls,
  visibilityFilter
})

export default votingApp
