
const poll = (state = {}, action) => {
  switch (action.type) {
    case 'ADD_POLL':
      return {
        id: action.id,
        title: action.title,
        options: action.options,
        votelimit: action.votelimit,
        deadline: action.deadline,
        status: action.status,
        voted: false
      }
    case 'VOTE':
      if (state.id !== action.id) {
        return state
      }
      return Object.assign({}, state, {
        voted: true
      })

    default:
      return state
  }
}

const polls = (state = [], action) => {
  switch (action.type) {
    case 'ADD_POLL':
      return [
        poll(undefined, action),
        ...state
      ]
    case 'VOTE':
      return state.map(p =>
        poll(p, action)
      )
    default:
      return state
  }
}

export default polls
