import React from 'react';
import './App.css';
import Navbar from './components/Navbar';
import VisiblePollList from './containers/VisiblePollList';
//import Vote from './components/Vote.js';
import { ButtonToolbar, Button , Grid, Row, Col} from 'react-bootstrap';
import {createPoll, poll} from './components/web3helper.js';
import { addPoll } from './actions';
import { connect } from 'react-redux';

const App = ({ params, route}) => {
  let store =  route.store
  const eventPoll = poll.NewPoll(null,{fromBlock: 0, toBlock: 'latest'}, (error, result) => {
    if (!error){
       let p = result.args;
       if(p.pollID.toNumber() >=  store.getState().polls.length){
       store.dispatch(addPoll(p.pollID.toNumber(),p.title,p.options,p.votelimit.toNumber(),p.deadline.toNumber(),p.status));
     }
    }
  })
  return (
      <div className="App">
        <div className="App-header">
          <h1>Eagle Vote</h1>
        </div>
        <Navbar/>
        <div>
          <Grid className="App-Content">
            <h2>{params.filter == 'VotedPolls' ? 'Voted Polls:' : 'Live Polls:'}</h2>
            <br></br>
            <VisiblePollList
              filter={params.filter || 'LivePolls'}
            />
          </Grid>
        </div>
      </div>
    )
  }
  App.contextTypes = {
    store: React.PropTypes.object.isRequired
  };
export default connect()(App);
