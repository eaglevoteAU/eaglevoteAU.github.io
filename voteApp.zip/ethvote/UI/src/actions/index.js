
export const addPoll = (id,title,options,votelimit,deadline,status) => {
  console.log(id,title,options,votelimit,deadline,status)
  return {
    type: 'ADD_POLL',
    id,title,options,votelimit,deadline,status
  }
}

export const setVisibilityFilter = (filter) => {
  return {
    type: 'SET_VISIBILITY_FILTER',
    filter
  }
}

export const voted = (id) => {
  return {
    type: 'VOTE',
    id
  }
}
