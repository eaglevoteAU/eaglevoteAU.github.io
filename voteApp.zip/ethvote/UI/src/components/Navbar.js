import { Button, Navbar,Nav, NavItem} from 'react-bootstrap';
import React  from 'react';
import NewPoll from './NewPoll.js';
import FilterLink from '../containers/FilterLink';
import {createPoll, poll} from '../components/web3helper.js';

const NavBar = () => {
  return (
  <Navbar collapseOnSelect>
    <Navbar.Header>
    
      <Navbar.Toggle />
    </Navbar.Header>
    <Navbar.Collapse>
      <Nav >
        <NavItem ><FilterLink filter="LivePolls"><Button>Live Polls</Button></FilterLink></NavItem>
        <NavItem ><FilterLink filter="VotedPolls"><Button>Voted Polls</Button></FilterLink></NavItem>
        <NavItem ><Button><NewPoll /></Button></NavItem>
        <NavItem ><Button onClick={createPoll.bind(this,"Is the sky blue?","Yes,No,Not sure",(100))}>Demo Poll</Button></NavItem>
      </Nav>
      </Navbar.Collapse>
    </Navbar>
  )
}

export default NavBar;
