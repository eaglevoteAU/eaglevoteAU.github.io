import React ,  { PropTypes } from 'react';
import { Panel } from 'react-bootstrap';

const Vote = ({id, title, address, vote}) => {
  return(
      <Panel>
        <h2>{title}<span className="right">#{id}</span></h2>
        <p>{address} voted: {vote}</p>
      </Panel>
    )
  }
Vote.propTypes ={
  id: PropTypes.number,
  title: PropTypes.string,
  address: PropTypes.string.isRequired,
  vote: PropTypes.string.isRequired
}
export default Vote;
