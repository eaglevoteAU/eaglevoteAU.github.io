import React, { PropTypes } from 'react';
import Poll from './Poll';
import { Row, Col} from 'react-bootstrap';
import setVisibilityFilter from '../actions';

const PollList = ({polls}) => {
  console.log(polls)
  if(polls === undefined){
    return null;

  }
  return(
  <Row id="flex" className="show-grid">
    {polls.map(poll =>
        <Col xs={12} sm={6} md={6}>
        <Poll
          key={poll.id}
          {...poll}
        />
        </Col>
    )}
  </Row>
)
}
PollList.propTypes = {
  polls: PropTypes.arrayOf(PropTypes.shape({
    id: PropTypes.number,
    title: PropTypes.string,
    options: PropTypes.string,
    votelimit: PropTypes.number,
    deadline: PropTypes.number,
    status: PropTypes.bool,
    voted: React.PropTypes.bool
  }))
}
export default PollList
