import lightwallet from 'eth-lightwallet/dist/lightwallet.min.js';
var HookedWeb3Provider = require("hooked-web3-provider");
import Web3 from 'web3';
import cookie from 'react-cookie';
import addPoll from '../actions';
import { connect } from 'react-redux';

var web3 = new Web3();
var keystore;
var user_address;

//cookie.remove('test')
if(cookie.load('test') != null){
  keystore = lightwallet.keystore.deserialize(cookie.load('test'))
  keystore.passwordProvider = function (callback) {
    var pw = prompt("Please enter password", "Password");
    callback(null, pw);
  };
  var provider = new HookedWeb3Provider({
    host: "http://localhost:8545",
    transaction_signer: keystore
  });
  web3.setProvider(provider)
  user_address = "0x" + keystore.getAddresses();
  //web3.personal.unlockAccount("0x90944173236e2437fcc939238dfaf79a6d4e4d0e", "1234");
  if(web3.eth.getBalance(user_address).toNumber() < 100000 )
  seed();
}
else{
  var password = prompt("Please enter a password", "Password");
  lightwallet.keystore.createVault({
    password: password}, function(err, ks){
      keystore = ks;
      ks.keyFromPassword(password, function (err, pwDerivedKey) {
        if (err) throw err;
        ks.generateNewAddress(pwDerivedKey);
        var user_address = "0x" + ks.getAddresses();

        ks.passwordProvider = function (callback) {
          var pw = prompt("Please enter password", "Password");
          callback(null, pw);
        };

        var provider = new HookedWeb3Provider({
          host: "http://localhost:8545",
          transaction_signer: ks
        });
        web3.setProvider(provider)

        if(web3.eth.getBalance(user_address ).toNumber() < 100000 )
        seed();
        var ksString = JSON.stringify(ks.serialize());
        cookie.save('test', ksString, { path: '/'})
      });
    });
  }

var pollABI = [{"constant":false,"inputs":[{"name":"_title","type":"string"},{"name":"_options","type":"string"},{"name":"_votelimit","type":"uint256"},{"name":"_deadlineInMinutes","type":"uint256"}],"name":"createPoll","outputs":[],"payable":false,"type":"function"},{"constant":true,"inputs":[{"name":"_pollID","type":"uint256"},{"name":"add","type":"address"}],"name":"hasVoted","outputs":[{"name":"","type":"bool"}],"payable":false,"type":"function"},{"constant":true,"inputs":[{"name":"","type":"uint256"}],"name":"polls","outputs":[{"name":"owner","type":"address"},{"name":"title","type":"string"},{"name":"options","type":"string"},{"name":"votelimit","type":"uint256"},{"name":"deadline","type":"uint256"},{"name":"numVotes","type":"uint256"}],"payable":false,"type":"function"},{"constant":false,"inputs":[{"name":"_pollID","type":"uint256"},{"name":"_choice","type":"uint256"}],"name":"vote","outputs":[{"name":"","type":"bool"}],"payable":false,"type":"function"},{"anonymous":false,"inputs":[{"indexed":false,"name":"pollID","type":"uint256"},{"indexed":false,"name":"vote","type":"uint256"},{"indexed":false,"name":"sender","type":"address"}],"name":"NewVote","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"name":"title","type":"string"},{"indexed":false,"name":"options","type":"string"},{"indexed":false,"name":"votelimit","type":"uint256"},{"indexed":false,"name":"deadline","type":"uint256"},{"indexed":false,"name":"status","type":"bool"},{"indexed":false,"name":"pollID","type":"uint256"}],"name":"NewPoll","type":"event"}]
export var poll = web3.eth.contract(pollABI).at("0xc10e1abac3444aec764a93a683b40a3e64f759b2");

export function Vote(id, vote, callback){
  poll.vote(id,vote,
    {
      from: user_address,
      gas: 31400,
      gasPrice: 180000000000
    }, function(err, result) {
      if (err != null) {
        console.log(err);
        alert("ERROR: Transaction didn't go through. See console.");
      } else {
        alert("Transaction Successful!");
        callback();
      }
    });
}

export function hasVoted(id){
  return poll.hasVoted(id, user_address)
}

function seed(){
  web3.eth.sendTransaction({
    from: web3.eth.accounts[0],
    to: user_address,
    value: 1000000000000000000,
    gas: 3141559,
    gasPrice: 30000
  }, function(err, result) {
    if (err != null) {
      console.log(err);
      alert("ERROR: Transaction didn't go through. See console.");
    } else {
      alert("Transaction Successful!");
    }
  });
}

export function createPoll(title, options, time){
  poll.createPoll(title,options,50,time,
    {
      from: user_address,
      gas: 314155,
      gasPrice: 180000000000
    }, function (e, contract){
      console.log(e, contract);
      if (typeof contract.address !== 'undefined') {
        console.log('Contract mined! address: ' + contract.address + ' transactionHash: ' + contract.transactionHash  );
      }
    })
}
