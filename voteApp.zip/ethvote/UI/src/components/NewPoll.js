import React from 'react';
import { Button, Modal, FormGroup, FormControl, ControlLabel } from 'react-bootstrap';
import _ from 'lodash';
import {createPoll} from './web3helper.js'


class NewPoll extends React.Component{

  constructor(props){
    super(props)
    this.state = {
      showModal: false,
      options: 2,
      disabled: false,
      title: "",
      values: ['',''],
      time: 0
    };
  }

  close = () => {
    this.setState({ showModal: false });
    this.setState({ options: 2 });
  }

  open = () => {
    this.setState({ showModal: true });
  }

  opt = () => {
    if(this.state.options >= 5)
    this.setState({disabled: true});

    this.setState({options: this.state.options + 1})
    this.setState({ values: [...this.state.values, ''] });
  }

  handleChange1 = (e) => {
    this.setState({ title: e.target.value });
  }

  handleChange2 = (e) => {
    var temp = this.state.values
    temp[e.target.id] = e.target.value
    this.setState({ values: temp });
  }

  handleChange3 = (e) => {
    this.setState({ time: e.target.value });
  }

  getValidationState() {
    const length = this.state.title.length;
    if (length > 2) return 'success';
    else if (length > 0) return 'error';
  }

  submit = () => {
    createPoll(this.state.title, this.state.values.toString(),this.state.time)
    this.close();
  }

  render() {
    var opts = [];
    for(var i = 0; i < this.state.options; i++){
      opts.push(
          <FormControl type="text" placeholder="Enter option" key={i} id={i.toString()} value={this.state.values[{i}]} onChange={this.handleChange2}/>
      )
    }
    return (
      <div onClick={this.open}>
       Create Poll
        <Modal show={this.state.showModal} onHide={this.close}>
          <Modal.Header closeButton>
            <Modal.Title>Create a new poll !</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <form>
                <FormGroup controlId="formBasicText"  validationState={this.getValidationState()}>
                  <ControlLabel>Title</ControlLabel>
                  <FormControl type="text" placeholder="Enter title" value={this.state.title} onChange={this.handleChange1}/>
                  <FormControl.Feedback />
                </FormGroup>
                <FormGroup controlId="formBasicText" >
                  <ControlLabel>Options (maxium 6)</ControlLabel>
                   {opts}
                </FormGroup>
                <FormGroup controlId="formBasicText" >
                  <ControlLabel>Poll ends in:</ControlLabel>
                  <FormControl type="number" placeholder="Enter minutes" value={this.state.time} onChange={this.handleChange3}/>
                </FormGroup>
            </form>
            <Button onClick={this.opt} disabled={this.state.disabled} >add options</Button>
          </Modal.Body>
          <Modal.Footer>
            <Button type="submit" onClick={this.submit}>Submit Poll</Button>
            <Button onClick={this.close}>Close</Button>
          </Modal.Footer>
        </Modal>
      </div>
    )
  }
}

export default NewPoll;
