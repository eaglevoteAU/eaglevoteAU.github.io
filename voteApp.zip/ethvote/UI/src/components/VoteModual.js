import React from 'react';
import { Button, Modal } from 'react-bootstrap';
import { Vote } from './web3helper.js';
import { voted } from  '../actions';
import { connect } from 'react-redux';

class PopUp extends React.Component{

  constructor(props){
    super(props)
    this.state = {
      showModal: false,
      vote: null,
      voted: this.props.voted
      }
  }

  close = () => {
    this.setState({ showModal: false });
  }

  open = () => {
    this.setState({ showModal: true });
  }

  selected = (id) => {
    this.active = true;
    this.setState({vote: id})
  }

  submit = () => {
    Vote(this.props.id, this.state.vote, () => {
        this.setState({voted: true})
        this.context.store.dispatch(voted(this.props.id))
        this.close()
    })
  }

  render() {
    return (
      <div className='voteModal'>
        <Button onClick={this.open} disabled={this.state.voted}>
          Vote!
        </Button>
        <Modal show={this.state.showModal} onHide={this.close}>
          <Modal.Header closeButton>
            <Modal.Title>{this.props.title}<span className="right">#{this.props.id}</span></Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <p>Options:</p>
            <ol className="voteOptions">
              {this.props.options.map( (opt, key) =>
                <li key={key}>
                  <Button onClick={this.selected.bind(this, key)}>{opt}</Button>
                </li>
              )}
            </ol>
          </Modal.Body>
          <Modal.Footer>
            <Button onClick={ this.submit.bind(this)}>Submit</Button>
            <Button onClick={this.close}>Close</Button>
          </Modal.Footer>
        </Modal>
      </div>
    )
  }
}
PopUp.contextTypes = {
  store: React.PropTypes.object.isRequired
};
export default PopUp;
