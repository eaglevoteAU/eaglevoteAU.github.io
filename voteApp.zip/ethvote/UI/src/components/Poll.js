import React , {Component} from 'react';
import { Panel, Fade } from 'react-bootstrap';
import PopUp from './VoteModual.js';
import { connect } from 'react-redux';

const Poll = ({id,title,options,votelimit,deadline,status,voted}) => {
    const list = options.split(',');
    return(
    <Panel id={voted ? "Voted" : "Poll"}>
      <h2 className="left">{title}<span className="right">#{id}</span></h2>
      <br></br>
      <div >
      <p className="left">Poll options:</p>
      <ol>
        {list.map((o,index) =>
          <li key={index}>
            {o}
          </li>
        )}
      </ol>
      </div>
      <br></br>
      <p>Vote limit: {votelimit}</p>
      <p>Poll ends in {deadline} minuntes.</p>
      <p>Poll status: {status ? "Open" : "Closed"}</p>
      <PopUp voted={voted} options={list} id={id} title={title} />
    </Panel>
  )
}

Poll.PropTypes = {
  id: React.PropTypes.number,
  title: React.PropTypes.string,
  options: React.PropTypes.string,
  votelimit: React.PropTypes.number,
  deadline: React.PropTypes.number,
  status: React.PropTypes.bool,
  voted: React.PropTypes.bool,
  votefunc: React.PropTypes.function
}
export default connect()(Poll);
