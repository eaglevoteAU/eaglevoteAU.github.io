import React from 'react';
import ReactDOM from 'react-dom';
import App from './App.js';
import './index.css';
import 'bootstrap/dist/css/bootstrap.css';
import { Provider } from 'react-redux';
import { createStore } from 'redux';
import votingApp from './reducers/index';
import { Router, Route, browserHistory } from 'react-router';

let store = createStore(votingApp)

console.log(store.getState())
let unsubscribe = store.subscribe(() =>
  console.log(store.getState())
)

const Root = ({store}) => (
  <Provider store={store}>
   <Router history={browserHistory}>
     <Route path="/(:filter)" component={App} store={store}/>
   </Router>
 </Provider>
);
ReactDOM.render(
  <Root store={store}/>,
  document.getElementById('root')
);
